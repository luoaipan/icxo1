document.writeln('<style type="text/css">');



document.writeln('<!--');



document.writeln('.black_1 {font-family: MS Shell Dlg;font-size: 12px;	line-height: 16px; color: #222222; text-decoration: none;}');



document.writeln('.black_1:hover {font-family: MS Shell Dlg;font-size: 12px;text-decoration: none;color: #003366;}');



document.writeln('.black_1:active {font-family: MS Shell Dlg;font-size: 12px;color: #FF3300;	text-decoration: none;}');



document.writeln('.black_1:visited {font-family: MS Shell Dlg;font-size: 12px;color: #222222;	text-decoration:  none;}');



document.writeln('.12 {');



document.writeln('	font-size: 12px;');



document.writeln('}');



document.writeln('-->');



document.writeln('</style>');



document.writeln('<table bgcolor="#FFFFFF" width="100%" border="0" cellspacing="0" cellpadding="0">');



document.writeln('  <tr> ');



document.writeln('    <td width="170" height="25">&nbsp;</td>');



document.writeln('    <td align="center" valign="bottom"><a href="http://about.icxo.com/about_1.htm" target="_blank" class="black_1">��������</a></td>');



document.writeln('    <td align="center" valign="bottom"><a href="http://about.icxo.com/about_b2.htm" target="_blank" class="black_1">��վ��ͼ</a></td>');



document.writeln('    <td align="center" valign="bottom"><a href="http://about.icxo.com/about_tp4.htm" target="_blank" class="black_1">��Ƹ����</a></td>');



document.writeln('    <td align="center" valign="bottom"><a href="http://about.icxo.com/about_9.htm" target="_blank" class="black_1">�����Ŷ�</a> ');



document.writeln('    </td>');



document.writeln('    <td align="center" valign="bottom"><a href="http://about.icxo.com/icxo_01.html" target="_blank" class="black_1">��վ���</a></td>');



document.writeln('    <td align="center" valign="bottom"><a href="http://daily.icxo.com/" target="_blank" class="black_1">���羭�����ձ�</a></td>');



document.writeln('    <td align="center" valign="bottom"><a href="http://about.icxo.com/about_12.htm" target="_blank" class="black_1">ý���ע</a></td>');



document.writeln('    <td align="center" valign="bottom"><a href="http://about.icxo.com/about_8.htm" target="_blank" class="black_1">��ϵ����</a></td>');



document.writeln('    <td width="170" valign="bottom">&nbsp;</td>');



document.writeln('  </tr>');



document.writeln('</table>');



document.writeln('<table bgcolor="#FFFFFF" width="100%" border="0" cellspacing="0" cellpadding="0">');



document.writeln('  <tr> ');



document.writeln('    <td height="26" align="center" class="12" valign="bottom"><a href="http://about.icxo.com/about_b3.htm" target="_blank" class="black_1">��Ȩ����</a>&nbsp;&nbsp;|&nbsp;&nbsp; ');



document.writeln('      <a href="http://about.icxo.com/about_b4.htm" target="_blank" class="black_1">��ȫ��ŵ</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="http://about.icxo.com/about_b5.htm" target="_blank class="black_1">�̱�����</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="http://about.icxo.com/about_b6.htm" target="_blank" class="black_1">ʹ������</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="http://about.icxo.com/about_b7.htm" target="_blank" class="black_1">��˽����</a></td>');



document.writeln('  </tr>');



document.writeln('  <tr> ');



document.writeln('    <td height="25" align="center" class="12">Copyright&copy;');



document.writeln('      2003-2009 World Executive Group. ���羭���˼��� ��Ȩ����</td>');



document.writeln('  </tr>');



document.writeln('</table>');



